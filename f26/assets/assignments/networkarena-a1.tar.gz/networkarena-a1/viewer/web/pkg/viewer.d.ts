/* tslint:disable */
/* eslint-disable */

export class LogPlayer {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Compute what's animating in the half-open interval (now-dt, now].
     * `summary_threshold` is the per-link packet count above which we
     * emit a `LinkSummary` instead of individual moving packets.
     */
    frame(now_ns: bigint, dt_ns: bigint, summary_threshold: number, min_visible_ns: bigint): any;
    /**
     * Every packet that egressed `link_id` between `from_ns` and
     * `to_ns` (inclusive). Used when the user clicks a high-density
     * link summary to drill in. Returns a JS array of
     * `{ packet_id, size_bytes, at_ns, arrive_at_ns }` objects.
     */
    inspect_link(link_id: number, from_ns: bigint, to_ns: bigint): any;
    /**
     * Find the most recent `PacketIngress` for `packet_id` at or before
     * `at_ns`. Used by the JS layer when the user clicks an in-flight
     * packet dot. Returns `JsValue::NULL` if not found.
     */
    inspect_packet(packet_id: bigint, at_ns: bigint): any;
    /**
     * Return the live state of a switch at the cursor, for the
     * inspector pane (only called while playback is paused).
     */
    inspect_switch(switch_id: number): any;
    constructor(bytes: Uint8Array);
    /**
     * Timestamp of the first event strictly after `at_ns`, or
     * `duration_ns` if none.
     */
    next_event_ns(at_ns: bigint): bigint;
    /**
     * Timestamp of the last event strictly before `at_ns`, or 0.
     */
    prev_event_ns(at_ns: bigint): bigint;
    /**
     * Move the cursor to `at_ns`. Forward seeks step events; backward
     * seeks rebuild from scratch.
     */
    seek(at_ns: bigint): void;
    topology(): any;
    readonly duration_ns: bigint;
}

export function _start(): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_logplayer_free: (a: number, b: number) => void;
    readonly _start: () => void;
    readonly logplayer_duration_ns: (a: number) => bigint;
    readonly logplayer_frame: (a: number, b: bigint, c: bigint, d: number, e: bigint) => number;
    readonly logplayer_inspect_link: (a: number, b: number, c: bigint, d: bigint) => number;
    readonly logplayer_inspect_packet: (a: number, b: bigint, c: bigint) => number;
    readonly logplayer_inspect_switch: (a: number, b: number) => number;
    readonly logplayer_new: (a: number, b: number, c: number) => void;
    readonly logplayer_next_event_ns: (a: number, b: bigint) => bigint;
    readonly logplayer_prev_event_ns: (a: number, b: bigint) => bigint;
    readonly logplayer_seek: (a: number, b: bigint) => void;
    readonly logplayer_topology: (a: number) => number;
    readonly __wbindgen_export: (a: number, b: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
