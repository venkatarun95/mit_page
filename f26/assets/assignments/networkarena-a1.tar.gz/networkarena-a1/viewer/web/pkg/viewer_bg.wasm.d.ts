/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_logplayer_free: (a: number, b: number) => void;
export const _start: () => void;
export const logplayer_duration_ns: (a: number) => bigint;
export const logplayer_frame: (a: number, b: bigint, c: bigint, d: number, e: bigint) => number;
export const logplayer_inspect_link: (a: number, b: number, c: bigint, d: bigint) => number;
export const logplayer_inspect_packet: (a: number, b: bigint, c: bigint) => number;
export const logplayer_inspect_switch: (a: number, b: number) => number;
export const logplayer_new: (a: number, b: number, c: number) => void;
export const logplayer_next_event_ns: (a: number, b: bigint) => bigint;
export const logplayer_prev_event_ns: (a: number, b: bigint) => bigint;
export const logplayer_seek: (a: number, b: bigint) => void;
export const logplayer_topology: (a: number) => number;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_start: () => void;
